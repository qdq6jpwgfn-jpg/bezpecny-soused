// functions/index.js
// Firebase Cloud Functions – Backend logika pro Bezpečný soused

const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const messaging = admin.messaging();

// ─── 1. Odeslání push notifikace při novém incidentu ─────────────────────────

exports.onIncidentCreated = functions.firestore
  .document('incidents/{incidentId}')
  .onCreate(async (snap, context) => {
    const incident = snap.data();
    const { latitude, longitude, street, houseNumber, description, userName } = incident;

    // Najdi uživatele v okruhu 100 m
    const radiusInDeg = 100 / 111000;

    const usersSnap = await db.collection('user_locations')
      .where('latitude', '>', latitude - radiusInDeg)
      .where('latitude', '<', latitude + radiusInDeg)
      .get();

    const tokens = [];
    const nearbyUsers = [];

    for (const userDoc of usersSnap.docs) {
      const userData = userDoc.data();
      const distance = haversineDistance(
        latitude, longitude,
        userData.latitude, userData.longitude
      );

      if (distance <= 100) {
        nearbyUsers.push({ uid: userDoc.id, distance: Math.round(distance) });
      }
    }

    // Načti FCM tokeny pro blízké uživatele
    for (const { uid, distance } of nearbyUsers) {
      const userDoc = await db.collection('users').doc(uid).get();
      if (userDoc.exists && userDoc.data().fcmToken) {
        tokens.push({ token: userDoc.data().fcmToken, distance });
      }
    }

    if (tokens.length === 0) return null;

    // Odešli personalizované notifikace
    const sendPromises = tokens.map(({ token, distance }) => {
      const isNearest = distance === Math.min(...tokens.map(t => t.distance));

      return messaging.send({
        token,
        notification: {
          title: '🚨 Incident v ulici!',
          body: `V ulici ${street} ${houseNumber} ${description}. ${
            isNearest ? `Nejbližší: TY (${distance} m). Jdeš?` : `${distance} m od tebe.`
          }`,
        },
        data: {
          incidentId: context.params.incidentId,
          street,
          houseNumber,
          distance: String(distance),
          type: 'incident',
        },
        android: {
          priority: 'high',
          notification: {
            channelId: 'incidents',
            defaultSound: true,
            defaultVibrateTimings: true,
          },
        },
        apns: {
          headers: { 'apns-priority': '10' },
          payload: {
            aps: {
              alert: {
                title: '🚨 Incident v ulici!',
                body: `V ulici ${street} ${houseNumber} - ${description}`,
              },
              sound: 'default',
              badge: 1,
              category: 'incident',
            },
          },
        },
      });
    });

    return Promise.allSettled(sendPromises);
  });


// ─── 2. GDPR: Automatické mazání incidentů po 7 dnech ──────────────────────

exports.cleanupExpiredIncidents = functions.pubsub
  .schedule('every 24 hours')
  .onRun(async () => {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const expiredSnap = await db.collection('incidents')
      .where('createdAt', '<', sevenDaysAgo.toISOString())
      .get();

    const batch = db.batch();
    expiredSnap.docs.forEach(doc => {
      batch.delete(doc.ref);
    });

    await batch.commit();
    console.log(`Smazáno ${expiredSnap.size} expirovaných incidentů`);
    return null;
  });


// ─── 3. Mazání user_locations starších než 30 minut ─────────────────────────

exports.cleanupStaleLocations = functions.pubsub
  .schedule('every 30 minutes')
  .onRun(async () => {
    const thirtyMinsAgo = new Date(Date.now() - 30 * 60 * 1000);

    const staleSnap = await db.collection('user_locations')
      .where('lastSeen', '<', thirtyMinsAgo.toISOString())
      .get();

    const batch = db.batch();
    staleSnap.docs.forEach(doc => batch.delete(doc.ref));
    await batch.commit();

    console.log(`Smazáno ${staleSnap.size} starých poloh uživatelů`);
    return null;
  });


// ─── 4. Přidání bodů při reakci na notifikaci ───────────────────────────────

exports.rewardUserForResponse = functions.https
  .onCall(async (data, context) => {
    if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Musíte být přihlášeni');

    const { incidentId, action } = data;
    const uid = context.auth.uid;

    let points = 0;
    if (action === 'go') points = 2;
    if (action === 'called_police') points = 5;

    if (points === 0) return { success: false };

    const userRef = db.collection('users').doc(uid);
    await userRef.update({
      points: admin.firestore.FieldValue.increment(points),
    });

    // Update level
    const userDoc = await userRef.get();
    const totalPoints = userDoc.data().points;
    const newLevel = Math.floor(totalPoints / 10) + 1;
    await userRef.update({ level: newLevel });

    return { success: true, pointsAdded: points, totalPoints, level: newLevel };
  });


// ─── Helper: Haversine distance in metres ────────────────────────────────────

function haversineDistance(lat1, lng1, lat2, lng2) {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
