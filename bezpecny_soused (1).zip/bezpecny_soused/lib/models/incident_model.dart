// lib/models/incident_model.dart

enum IncidentType { photo, video, text }

class IncidentModel {
  final String id;
  final String userId;
  final String userName;
  final String street;
  final String houseNumber;
  final double latitude;
  final double longitude;
  final String description;
  final IncidentType type;
  final String? mediaUrl;
  final DateTime createdAt;
  final bool isActive;

  IncidentModel({
    required this.id,
    required this.userId,
    required this.userName,
    required this.street,
    required this.houseNumber,
    required this.latitude,
    required this.longitude,
    required this.description,
    required this.type,
    this.mediaUrl,
    required this.createdAt,
    this.isActive = true,
  });

  String get timeAgo {
    final diff = DateTime.now().difference(createdAt);
    if (diff.inMinutes < 1) return 'Právě teď';
    if (diff.inMinutes < 60) return 'před ${diff.inMinutes} min';
    if (diff.inHours < 24) return 'před ${diff.inHours} h';
    return 'před ${diff.inDays} dny';
  }

  String get locationLabel => '$street $houseNumber';

  factory IncidentModel.fromMap(Map<String, dynamic> map, String id) {
    return IncidentModel(
      id: id,
      userId: map['userId'] ?? '',
      userName: map['userName'] ?? 'Anonymní soused',
      street: map['street'] ?? '',
      houseNumber: map['houseNumber'] ?? '',
      latitude: (map['latitude'] ?? 0.0).toDouble(),
      longitude: (map['longitude'] ?? 0.0).toDouble(),
      description: map['description'] ?? '',
      type: IncidentType.values.firstWhere(
        (e) => e.name == map['type'],
        orElse: () => IncidentType.text,
      ),
      mediaUrl: map['mediaUrl'],
      createdAt: DateTime.parse(map['createdAt'] ?? DateTime.now().toIso8601String()),
      isActive: map['isActive'] ?? true,
    );
  }

  Map<String, dynamic> toMap() => {
    'userId': userId,
    'userName': userName,
    'street': street,
    'houseNumber': houseNumber,
    'latitude': latitude,
    'longitude': longitude,
    'description': description,
    'type': type.name,
    'mediaUrl': mediaUrl,
    'createdAt': createdAt.toIso8601String(),
    'isActive': isActive,
    // GDPR: auto-delete after 7 days
    'expiresAt': createdAt.add(const Duration(days: 7)).toIso8601String(),
  };
}
