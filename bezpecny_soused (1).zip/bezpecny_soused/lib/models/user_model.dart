// lib/models/user_model.dart
class UserModel {
  final String uid;
  final String name;
  final String street;
  final String apartmentNumber;
  final String phone;
  final int points;
  final int level;
  final GeoPoint? location;

  UserModel({
    required this.uid,
    required this.name,
    required this.street,
    required this.apartmentNumber,
    required this.phone,
    this.points = 0,
    this.level = 1,
    this.location,
  });

  String get displayName => '$name, $apartmentNumber';

  String get levelLabel {
    if (level >= 5) return 'Soused level 5 ⭐';
    if (level >= 3) return 'Soused level $level';
    return 'Soused level $level';
  }

  bool get hasInsuranceDiscount => points >= 5;

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] ?? '',
      name: map['name'] ?? '',
      street: map['street'] ?? '',
      apartmentNumber: map['apartmentNumber'] ?? '',
      phone: map['phone'] ?? '',
      points: map['points'] ?? 0,
      level: map['level'] ?? 1,
    );
  }

  Map<String, dynamic> toMap() => {
    'uid': uid,
    'name': name,
    'street': street,
    'apartmentNumber': apartmentNumber,
    'phone': phone,
    'points': points,
    'level': level,
    'updatedAt': DateTime.now().toIso8601String(),
  };
}

// Simple GeoPoint replacement (use firebase GeoPoint in real app)
class GeoPoint {
  final double latitude;
  final double longitude;
  GeoPoint(this.latitude, this.longitude);
}
