// lib/services/auth_service.dart
import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  UserModel? _userModel;
  UserModel? get userModel => _userModel;

  String? _verificationId;

  // ─── SMS phone verification ───────────────────────────────────────────────

  Future<void> sendSmsCode(String phoneNumber) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: (FirebaseAuthException e) {
        throw Exception('Ověření selhalo: ${e.message}');
      },
      codeSent: (String verificationId, int? resendToken) {
        _verificationId = verificationId;
        notifyListeners();
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        _verificationId = verificationId;
      },
    );
  }

  Future<UserCredential> verifySmsCode(String smsCode) async {
    if (_verificationId == null) throw Exception('Nejprve odešlete SMS kód');
    final credential = PhoneAuthProvider.credential(
      verificationId: _verificationId!,
      smsCode: smsCode,
    );
    return await _auth.signInWithCredential(credential);
  }

  // ─── Google Sign-In ───────────────────────────────────────────────────────

  Future<UserCredential?> signInWithGoogle() async {
    final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
    if (googleUser == null) return null;

    final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    return await _auth.signInWithCredential(credential);
  }

  // ─── Apple Sign-In (iOS) ──────────────────────────────────────────────────

  Future<UserCredential> signInWithApple() async {
    final appleProvider = AppleAuthProvider();
    return await _auth.signInWithProvider(appleProvider);
  }

  // ─── User profile ─────────────────────────────────────────────────────────

  Future<void> saveUserProfile({
    required String name,
    required String street,
    required String apartmentNumber,
  }) async {
    final user = _auth.currentUser;
    if (user == null) throw Exception('Uživatel není přihlášen');

    final userModel = UserModel(
      uid: user.uid,
      name: name,
      street: street,
      apartmentNumber: apartmentNumber,
      phone: user.phoneNumber ?? '',
      points: 0,
      level: 1,
    );

    await _db.collection('users').doc(user.uid).set(userModel.toMap());
    _userModel = userModel;
    notifyListeners();
  }

  Future<void> loadUserProfile() async {
    final user = _auth.currentUser;
    if (user == null) return;

    final doc = await _db.collection('users').doc(user.uid).get();
    if (doc.exists) {
      _userModel = UserModel.fromMap(doc.data()!);
      notifyListeners();
    }
  }

  Future<bool> hasProfile() async {
    final user = _auth.currentUser;
    if (user == null) return false;
    final doc = await _db.collection('users').doc(user.uid).get();
    return doc.exists;
  }

  // ─── Points ───────────────────────────────────────────────────────────────

  Future<void> addPoints(int points) async {
    final user = _auth.currentUser;
    if (user == null || _userModel == null) return;

    final newPoints = _userModel!.points + points;
    final newLevel = (newPoints / 10).floor() + 1;

    await _db.collection('users').doc(user.uid).update({
      'points': newPoints,
      'level': newLevel,
    });

    _userModel = UserModel(
      uid: _userModel!.uid,
      name: _userModel!.name,
      street: _userModel!.street,
      apartmentNumber: _userModel!.apartmentNumber,
      phone: _userModel!.phone,
      points: newPoints,
      level: newLevel,
    );
    notifyListeners();
  }

  // ─── Sign out ─────────────────────────────────────────────────────────────

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
    _userModel = null;
    notifyListeners();
  }
}
