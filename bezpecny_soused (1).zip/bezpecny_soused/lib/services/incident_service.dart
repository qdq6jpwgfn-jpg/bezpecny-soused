// lib/services/incident_service.dart
import 'dart:io';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:geolocator/geolocator.dart';
import '../models/incident_model.dart';

class IncidentService extends ChangeNotifier {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  List<IncidentModel> _incidents = [];
  List<IncidentModel> get incidents => _incidents;

  // ─── Location ─────────────────────────────────────────────────────────────

  Future<Position> getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) throw Exception('GPS není zapnuté');

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception('Přístup k poloze byl odmítnut');
      }
    }

    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
  }

  // ─── Fetch nearby incidents ───────────────────────────────────────────────

  Stream<List<IncidentModel>> nearbyIncidentsStream(
    double lat,
    double lng, {
    double radiusMeters = 150,
  }) {
    // Firestore geo queries use bounding box + client-side filter
    final double latDelta = radiusMeters / 111000;
    final double lngDelta = radiusMeters / (111000 * cos(lat * pi / 180));

    return _db
        .collection('incidents')
        .where('latitude', isGreaterThan: lat - latDelta)
        .where('latitude', isLessThan: lat + latDelta)
        .where('isActive', isEqualTo: true)
        .orderBy('latitude')
        .orderBy('createdAt', descending: true)
        .limit(20)
        .snapshots()
        .map((snap) {
      final list = snap.docs
          .map((d) => IncidentModel.fromMap(d.data(), d.id))
          .where((incident) {
        // Client-side longitude filter
        final distance = _distanceMeters(lat, lng, incident.latitude, incident.longitude);
        return distance <= radiusMeters;
      })
          .toList();
      _incidents = list;
      return list;
    });
  }

  // ─── Report incident ──────────────────────────────────────────────────────

  Future<String> reportIncident({
    required String userId,
    required String userName,
    required String street,
    required String houseNumber,
    required double latitude,
    required double longitude,
    required String description,
    required IncidentType type,
    File? mediaFile,
  }) async {
    String? mediaUrl;

    // Upload media if present
    if (mediaFile != null) {
      final fileName = '${DateTime.now().millisecondsSinceEpoch}_${type.name}';
      final ref = _storage.ref('incidents/$userId/$fileName');
      await ref.putFile(mediaFile);
      mediaUrl = await ref.getDownloadURL();
    }

    final incident = IncidentModel(
      id: '',
      userId: userId,
      userName: userName,
      street: street,
      houseNumber: houseNumber,
      latitude: latitude,
      longitude: longitude,
      description: description,
      type: type,
      mediaUrl: mediaUrl,
      createdAt: DateTime.now(),
    );

    final doc = await _db.collection('incidents').add(incident.toMap());
    return doc.id;
  }

  // ─── Get active neighbours count ─────────────────────────────────────────

  Stream<int> activeNeighboursStream(double lat, double lng) {
    final double latDelta = 150 / 111000;

    return _db
        .collection('user_locations')
        .where('latitude', isGreaterThan: lat - latDelta)
        .where('latitude', isLessThan: lat + latDelta)
        .where('lastSeen', isGreaterThan: DateTime.now()
            .subtract(const Duration(minutes: 30))
            .toIso8601String())
        .snapshots()
        .map((snap) {
      return snap.docs.where((d) {
        final lngDelta = 150 / (111000 * cos(lat * pi / 180));
        final docLng = (d.data()['longitude'] ?? 0.0).toDouble();
        return (docLng - lng).abs() <= lngDelta;
      }).length;
    });
  }

  // ─── Update user location ─────────────────────────────────────────────────

  Future<void> updateUserLocation(String userId, double lat, double lng) async {
    await _db.collection('user_locations').doc(userId).set({
      'latitude': lat,
      'longitude': lng,
      'lastSeen': DateTime.now().toIso8601String(),
    });
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────

  double _distanceMeters(double lat1, double lng1, double lat2, double lng2) {
    const R = 6371000.0;
    final dLat = (lat2 - lat1) * pi / 180;
    final dLng = (lng2 - lng1) * pi / 180;
    final a = sin(dLat / 2) * sin(dLat / 2) +
        cos(lat1 * pi / 180) * cos(lat2 * pi / 180) * sin(dLng / 2) * sin(dLng / 2);
    return R * 2 * atan2(sqrt(a), sqrt(1 - a));
  }
}
