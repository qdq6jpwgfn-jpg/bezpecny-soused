// lib/services/notification_service.dart
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:url_launcher/url_launcher.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._();
  factory NotificationService() => _instance;
  NotificationService._();

  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  // Notification channels
  static const AndroidNotificationChannel _incidentChannel =
      AndroidNotificationChannel(
    'incidents',
    'Incidenty v okolí',
    description: 'Upozornění na bezpečnostní incidenty ve vašem okolí.',
    importance: Importance.high,
  );

  Future<void> initialize() async {
    // Request permissions
    await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    // Local notifications setup
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    await _localNotifications.initialize(
      const InitializationSettings(android: androidSettings, iOS: iosSettings),
      onDidReceiveNotificationResponse: _handleNotificationTap,
    );

    // Create Android channel
    await _localNotifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(_incidentChannel);

    // Handle foreground messages
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);

    // Handle background/terminated taps
    FirebaseMessaging.onMessageOpenedApp.listen(_handleBackgroundMessageTap);
  }

  void _handleForegroundMessage(RemoteMessage message) {
    final notification = message.notification;
    if (notification == null) return;

    final street = message.data['street'] ?? '';
    final distance = message.data['distance'] ?? '';

    _showIncidentNotification(
      title: notification.title ?? 'Incident v okolí!',
      body: notification.body ??
          'V ulici $street někdo šmejdí. Nejbližší: TY ($distance). Jdeš?',
      data: message.data,
    );
  }

  void _handleBackgroundMessageTap(RemoteMessage message) {
    // Navigate to incident detail
  }

  void _handleNotificationTap(NotificationResponse response) {
    final payload = response.payload;
    if (payload == null) return;

    // Handle action buttons
    if (response.actionId == 'call_police') {
      launchUrl(Uri.parse('tel:158'));
    }
    // 'go' action = navigate in app (handled by app router)
  }

  Future<void> _showIncidentNotification({
    required String title,
    required String body,
    required Map<String, dynamic> data,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      _incidentChannel.id,
      _incidentChannel.name,
      channelDescription: _incidentChannel.description,
      importance: Importance.high,
      priority: Priority.high,
      actions: const [
        AndroidNotificationAction('go', 'Jdu ✅'),
        AndroidNotificationAction('call_police', 'Zavolat policii 158 🚨',
            showsUserInterface: true),
      ],
    );

    const iosDetails = DarwinNotificationDetails(
      categoryIdentifier: 'incident',
      interruptionLevel: InterruptionLevel.timeSensitive,
    );

    await _localNotifications.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      title,
      body,
      NotificationDetails(android: androidDetails, iOS: iosDetails),
      payload: data['incidentId'],
    );
  }

  Future<String?> getToken() => _fcm.getToken();

  // Save FCM token to Firestore for targeting
  Future<void> saveToken(String userId) async {
    final token = await getToken();
    if (token == null) return;
    // Save to Firestore: users/{uid}/fcmToken = token
    // This is done in auth service after login
  }
}

// Background message handler (must be top-level)
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Handle background messages
}
