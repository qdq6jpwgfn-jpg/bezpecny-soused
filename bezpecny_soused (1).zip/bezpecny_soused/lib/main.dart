// lib/main.dart
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:provider/provider.dart';
import 'services/auth_service.dart';
import 'services/incident_service.dart';
import 'services/notification_service.dart';
import 'theme/app_theme.dart';
import 'screens/auth/phone_auth_screen.dart';
import 'screens/home/home_screen.dart';

// Must be top-level for Firebase background handler
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  // Background notifications handler
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  // Initialize notifications
  await NotificationService().initialize();

  runApp(const BezpecnySousedApp());
}

class BezpecnySousedApp extends StatelessWidget {
  const BezpecnySousedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => IncidentService()),
      ],
      child: MaterialApp(
        title: 'Bezpečný soused',
        theme: AppTheme.theme,
        debugShowCheckedModeBanner: false,
        locale: const Locale('cs', 'CZ'),
        home: const _AppRouter(),
      ),
    );
  }
}

class _AppRouter extends StatelessWidget {
  const _AppRouter();

  @override
  Widget build(BuildContext context) {
    final authService = context.watch<AuthService>();

    return StreamBuilder(
      stream: authService.authStateChanges,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.shield_rounded, color: Color(0xFF007AFF), size: 64),
                  SizedBox(height: 16),
                  CircularProgressIndicator(color: Color(0xFF007AFF)),
                ],
              ),
            ),
          );
        }

        if (snap.data == null) {
          return const PhoneAuthScreen();
        }

        // User is logged in - check profile
        return FutureBuilder<bool>(
          future: authService.hasProfile(),
          builder: (context, profileSnap) {
            if (!profileSnap.hasData) {
              return const Scaffold(
                body: Center(child: CircularProgressIndicator()),
              );
            }

            if (!profileSnap.data!) {
              // Redirect to profile setup (handled in SmsVerificationScreen)
              return const PhoneAuthScreen();
            }

            // Load and show home
            return FutureBuilder(
              future: authService.loadUserProfile(),
              builder: (context, _) => const HomeScreen(),
            );
          },
        );
      },
    );
  }
}
