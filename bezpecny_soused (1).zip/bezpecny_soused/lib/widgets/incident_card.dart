// lib/widgets/incident_card.dart
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/incident_model.dart';
import '../theme/app_theme.dart';

class IncidentCard extends StatelessWidget {
  final IncidentModel incident;

  const IncidentCard({super.key, required this.incident});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Media thumbnail
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(14),
              bottomLeft: Radius.circular(14),
            ),
            child: SizedBox(
              width: 80,
              height: 80,
              child: _buildThumbnail(),
            ),
          ),
          // Content
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      _buildTypeChip(),
                      const Spacer(),
                      Text(
                        incident.timeAgo,
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    incident.description,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.location_on_outlined, size: 13, color: AppColors.textSecondary),
                      const SizedBox(width: 2),
                      Expanded(
                        child: Text(
                          incident.locationLabel,
                          style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildThumbnail() {
    if (incident.mediaUrl != null && incident.type == IncidentType.photo) {
      return CachedNetworkImage(
        imageUrl: incident.mediaUrl!,
        fit: BoxFit.cover,
        placeholder: (_, __) => const ColoredBox(
          color: AppColors.surface,
          child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
        ),
        errorWidget: (_, __, ___) => _buildIconPlaceholder(),
      );
    }
    return _buildIconPlaceholder();
  }

  Widget _buildIconPlaceholder() {
    IconData icon;
    Color color;

    switch (incident.type) {
      case IncidentType.photo:
        icon = Icons.image_outlined;
        color = AppColors.primary;
        break;
      case IncidentType.video:
        icon = Icons.videocam_rounded;
        color = AppColors.danger;
        break;
      case IncidentType.text:
        icon = Icons.text_snippet_outlined;
        color = AppColors.textSecondary;
        break;
    }

    return ColoredBox(
      color: color.withOpacity(0.1),
      child: Center(
        child: Icon(icon, color: color, size: 32),
      ),
    );
  }

  Widget _buildTypeChip() {
    String label;
    Color color;

    switch (incident.type) {
      case IncidentType.photo:
        label = 'Foto';
        color = AppColors.primary;
        break;
      case IncidentType.video:
        label = 'Video';
        color = AppColors.danger;
        break;
      case IncidentType.text:
        label = 'Zpráva';
        color = AppColors.textSecondary;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        label,
        style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w600),
      ),
    );
  }
}
