// lib/screens/points/points_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/auth_service.dart';
import '../../theme/app_theme.dart';

class PointsScreen extends StatelessWidget {
  const PointsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().userModel;

    return Scaffold(
      appBar: AppBar(title: const Text('Moje body')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Level card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.primary, Color(0xFF0055CC)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  const Icon(Icons.shield_rounded, color: Colors.white, size: 56),
                  const SizedBox(height: 12),
                  Text(
                    user?.levelLabel ?? 'Soused level 1',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${user?.points ?? 0} bodů celkem',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Progress to next level
                  _buildProgressBar(user?.points ?? 0),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Insurance discount banner (after 5 points)
            if (user?.hasInsuranceDiscount == true)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  color: AppColors.success.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.success.withOpacity(0.4)),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.success,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.local_offer_rounded, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 16),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '🎉 Sleva na pojištění!',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: AppColors.success,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Kontaktujte svou pojišťovnu a uveďte kód SOUSED5.',
                            style: TextStyle(fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

            // How to earn points
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Jak získat body',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
              ),
            ),
            const SizedBox(height: 12),
            _buildEarningCard(
              icon: Icons.warning_rounded,
              color: AppColors.danger,
              title: 'Nahlásit incident',
              points: '3 body',
              description: 'Odešlete hlášení s popisem, fotkou nebo videem.',
            ),
            _buildEarningCard(
              icon: Icons.check_circle_rounded,
              color: AppColors.success,
              title: 'Reagovat na výzvu',
              points: '2 body',
              description: 'Potvrďte kontrolu místa po obdržení notifikace.',
            ),
            _buildEarningCard(
              icon: Icons.local_police_rounded,
              color: AppColors.primary,
              title: 'Přivolat policii',
              points: '5 bodů',
              description: 'Kontaktujete policii při skutečném nebezpečí.',
            ),

            const SizedBox(height: 20),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Odměny',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
              ),
            ),
            const SizedBox(height: 12),
            _buildRewardCard(
              icon: Icons.local_offer_rounded,
              title: 'Sleva na pojištění',
              requirement: '5+ bodů',
              unlocked: (user?.points ?? 0) >= 5,
            ),
            _buildRewardCard(
              icon: Icons.star_rounded,
              title: 'Soused měsíce',
              requirement: '20+ bodů',
              unlocked: (user?.points ?? 0) >= 20,
            ),
            _buildRewardCard(
              icon: Icons.verified_rounded,
              title: 'Ověřený strážce',
              requirement: '50+ bodů',
              unlocked: (user?.points ?? 0) >= 50,
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressBar(int points) {
    final nextMilestone = ((points / 10).floor() + 1) * 10;
    final progress = (points % 10) / 10.0;

    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: progress,
            backgroundColor: Colors.white30,
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
            minHeight: 8,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          '${points % 10}/10 do dalšího levelu',
          style: const TextStyle(color: Colors.white70, fontSize: 13),
        ),
      ],
    );
  }

  Widget _buildEarningCard({
    required IconData icon,
    required Color color,
    required String title,
    required String points,
    required String description,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
                Text(description, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(points, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildRewardCard({
    required IconData icon,
    required String title,
    required String requirement,
    required bool unlocked,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: unlocked ? AppColors.success.withOpacity(0.08) : AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: unlocked ? Border.all(color: AppColors.success.withOpacity(0.4)) : null,
      ),
      child: Row(
        children: [
          Icon(icon, color: unlocked ? AppColors.success : AppColors.textSecondary, size: 28),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: unlocked ? AppColors.textPrimary : AppColors.textSecondary,
                  ),
                ),
                Text(
                  requirement,
                  style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
          Icon(
            unlocked ? Icons.lock_open_rounded : Icons.lock_outline_rounded,
            color: unlocked ? AppColors.success : AppColors.textSecondary,
          ),
        ],
      ),
    );
  }
}
