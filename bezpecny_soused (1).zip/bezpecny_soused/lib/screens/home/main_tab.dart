// lib/screens/home/main_tab.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import '../../services/auth_service.dart';
import '../../services/incident_service.dart';
import '../../models/incident_model.dart';
import '../../theme/app_theme.dart';
import '../../widgets/incident_card.dart';
import '../report/report_incident_screen.dart';

class MainTab extends StatefulWidget {
  const MainTab({super.key});

  @override
  State<MainTab> createState() => _MainTabState();
}

class _MainTabState extends State<MainTab> {
  GoogleMapController? _mapController;
  Position? _position;
  Set<Marker> _markers = {};
  List<IncidentModel> _incidents = [];
  bool _locationLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadLocation();
  }

  Future<void> _loadLocation() async {
    try {
      final pos = await context.read<IncidentService>().getCurrentLocation();
      if (mounted) {
        setState(() {
          _position = pos;
          _locationLoaded = true;
        });
        await context.read<IncidentService>().updateUserLocation(
          context.read<AuthService>().currentUser!.uid,
          pos.latitude,
          pos.longitude,
        );
      }
    } catch (e) {
      // Use a default position if GPS not available
      if (mounted) setState(() => _locationLoaded = true);
    }
  }

  void _updateMarkers(List<IncidentModel> incidents) {
    final Set<Marker> markers = {};
    for (final i in incidents) {
      markers.add(Marker(
        markerId: MarkerId(i.id),
        position: LatLng(i.latitude, i.longitude),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        infoWindow: InfoWindow(title: i.description, snippet: i.locationLabel),
      ));
    }
    setState(() => _markers = markers);
  }

  Future<void> _openReportScreen() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ReportIncidentScreen()),
    );
    if (result == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Hlášení bylo odesláno sousedům!'),
          backgroundColor: AppColors.success,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().userModel;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // ─── Header ────────────────────────────────────────────────
            _buildHeader(user),

            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    // ─── Report button ──────────────────────────────────
                    const SizedBox(height: 20),
                    _buildReportButton(),
                    const SizedBox(height: 20),

                    // ─── Map ────────────────────────────────────────────
                    _buildMap(),
                    const SizedBox(height: 16),

                    // ─── Recent incidents ───────────────────────────────
                    _buildRecentIncidents(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(user) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: Row(
        children: [
          // Logo
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.shield_rounded, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Bezpečný soused',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textSecondary,
                  ),
                ),
                if (user != null)
                  Text(
                    '${user.name}, ${user.apartmentNumber}',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary,
                    ),
                  ),
              ],
            ),
          ),
          // Notification bell
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {},
          ),
        ],
      ),
    );
  }

  Widget _buildReportButton() {
    return GestureDetector(
      onTap: _openReportScreen,
      child: Container(
        width: 160,
        height: 160,
        decoration: BoxDecoration(
          color: AppColors.danger,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: AppColors.danger.withOpacity(0.4),
              blurRadius: 24,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.warning_rounded, color: Colors.white, size: 40),
            SizedBox(height: 8),
            Text(
              'Nahlásit',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'podezření',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMap() {
    if (!_locationLoaded) {
      return const SizedBox(
        height: 200,
        child: Center(child: CircularProgressIndicator()),
      );
    }

    final lat = _position?.latitude ?? 50.0755;
    final lng = _position?.longitude ?? 14.4378;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: SizedBox(
          height: 200,
          child: StreamBuilder<List<IncidentModel>>(
            stream: context.read<IncidentService>().nearbyIncidentsStream(lat, lng),
            builder: (context, snap) {
              final incidents = snap.data ?? [];
              if (incidents.isNotEmpty) {
                _updateMarkers(incidents);
                _incidents = incidents;
              }

              return GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: LatLng(lat, lng),
                  zoom: 16,
                ),
                onMapCreated: (c) => _mapController = c,
                markers: _markers,
                myLocationEnabled: true,
                myLocationButtonEnabled: false,
                zoomControlsEnabled: false,
                mapToolbarEnabled: false,
                circles: {
                  Circle(
                    circleId: const CircleId('radius'),
                    center: LatLng(lat, lng),
                    radius: 150,
                    fillColor: AppColors.primary.withOpacity(0.08),
                    strokeColor: AppColors.primary.withOpacity(0.3),
                    strokeWidth: 1,
                  ),
                },
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildRecentIncidents() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Nedávná hlášení',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 12),
          if (_incidents.isEmpty)
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Center(
                child: Column(
                  children: [
                    Icon(Icons.check_circle_outline, color: AppColors.success, size: 40),
                    SizedBox(height: 8),
                    Text(
                      'Vše v pořádku!\nŽádné incidenty v okolí.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ),
            )
          else
            ...(_incidents.take(5).map((i) => IncidentCard(incident: i))),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
