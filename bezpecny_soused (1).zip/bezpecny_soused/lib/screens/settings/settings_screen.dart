// lib/screens/settings/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../services/auth_service.dart';
import '../../theme/app_theme.dart';
import '../auth/phone_auth_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().userModel;

    return Scaffold(
      appBar: AppBar(title: const Text('Nastavení')),
      body: ListView(
        children: [
          // Profile card
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: AppColors.primary,
                  child: Text(
                    user?.name.isNotEmpty == true ? user!.name[0].toUpperCase() : '?',
                    style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      user?.name ?? 'Načítám...',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      user != null ? '${user.street}, byt ${user.apartmentNumber}' : '',
                      style: const TextStyle(color: AppColors.textSecondary),
                    ),
                    if (user != null)
                      Text(
                        user.levelLabel,
                        style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w500),
                      ),
                  ],
                ),
              ],
            ),
          ),

          _buildSection('Bezpečnost & soukromí', [
            _buildTile(
              icon: Icons.notifications_outlined,
              title: 'Notifikace',
              subtitle: 'Upozornění na incidenty v okolí',
              trailing: Switch(
                value: true,
                onChanged: (_) {},
                activeColor: AppColors.primary,
              ),
            ),
            _buildTile(
              icon: Icons.location_on_outlined,
              title: 'Sdílení polohy',
              subtitle: 'Pouze při aktivním použití aplikace',
              trailing: const Icon(Icons.chevron_right),
              onTap: () {},
            ),
            _buildTile(
              icon: Icons.delete_outline,
              title: 'Smazat moje data',
              subtitle: 'GDPR – smazání všech osobních dat',
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showDeleteDialog(context),
            ),
          ]),

          _buildSection('Informace', [
            _buildTile(
              icon: Icons.info_outline,
              title: 'O aplikaci',
              subtitle: 'Verze 1.0.0',
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showAboutDialog(context),
            ),
            _buildTile(
              icon: Icons.description_outlined,
              title: 'Podmínky použití',
              trailing: const Icon(Icons.chevron_right),
              onTap: () => launchUrl(Uri.parse('https://bezpecnysoused.cz/terms')),
            ),
            _buildTile(
              icon: Icons.privacy_tip_outlined,
              title: 'Zásady ochrany dat',
              trailing: const Icon(Icons.chevron_right),
              onTap: () => launchUrl(Uri.parse('https://bezpecnysoused.cz/privacy')),
            ),
          ]),

          Padding(
            padding: const EdgeInsets.all(16),
            child: OutlinedButton.icon(
              onPressed: () => _signOut(context),
              icon: const Icon(Icons.logout_rounded, color: AppColors.danger),
              label: const Text('Odhlásit se', style: TextStyle(color: AppColors.danger)),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 52),
                side: const BorderSide(color: AppColors.danger),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),

          const Padding(
            padding: EdgeInsets.only(bottom: 24),
            child: Center(
              child: Text(
                'Data jsou automaticky mazána po 7 dnech (GDPR)',
                style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(String title, List<Widget> tiles) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppColors.textSecondary,
            ),
          ),
        ),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(children: tiles),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildTile({
    required IconData icon,
    required String title,
    String? subtitle,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primary),
      title: Text(title),
      subtitle: subtitle != null ? Text(subtitle, style: const TextStyle(fontSize: 13)) : null,
      trailing: trailing,
      onTap: onTap,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    );
  }

  void _signOut(BuildContext context) async {
    await context.read<AuthService>().signOut();
    if (context.mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const PhoneAuthScreen()),
        (_) => false,
      );
    }
  }

  void _showDeleteDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Smazat data'),
        content: const Text('Opravdu chcete smazat všechna svá data? Tato akce je nevratná.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Zrušit')),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              // TODO: Delete user data from Firestore
            },
            child: const Text('Smazat', style: TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
  }

  void _showAboutDialog(BuildContext context) {
    showAboutDialog(
      context: context,
      applicationName: 'Bezpečný soused',
      applicationVersion: '1.0.0',
      applicationIcon: const Icon(Icons.shield_rounded, color: AppColors.primary, size: 48),
      children: const [
        Text('Komunitní bezpečnostní aplikace pro hlídání sousedství.'),
      ],
    );
  }
}
