// lib/screens/report/report_incident_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:camera/camera.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import '../../services/auth_service.dart';
import '../../services/incident_service.dart';
import '../../models/incident_model.dart';
import '../../theme/app_theme.dart';

class ReportIncidentScreen extends StatefulWidget {
  const ReportIncidentScreen({super.key});

  @override
  State<ReportIncidentScreen> createState() => _ReportIncidentScreenState();
}

class _ReportIncidentScreenState extends State<ReportIncidentScreen> {
  CameraController? _cameraController;
  List<CameraDescription> _cameras = [];
  bool _isCameraReady = false;
  bool _isRecording = false;
  bool _showForm = false;

  File? _mediaFile;
  IncidentType _mediaType = IncidentType.photo;
  final _descriptionController = TextEditingController();

  // Location
  Position? _position;
  String _street = '';
  String _houseNumber = '';
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _initCamera();
    _loadLocation();
  }

  Future<void> _initCamera() async {
    try {
      _cameras = await availableCameras();
      if (_cameras.isEmpty) return;

      _cameraController = CameraController(
        _cameras.first,
        ResolutionPreset.high,
        enableAudio: true,
      );
      await _cameraController!.initialize();
      if (mounted) setState(() => _isCameraReady = true);
    } catch (e) {
      // Camera not available - go directly to text form
      if (mounted) setState(() => _showForm = true);
    }
  }

  Future<void> _loadLocation() async {
    try {
      final pos = await context.read<IncidentService>().getCurrentLocation();
      final placemarks = await placemarkFromCoordinates(pos.latitude, pos.longitude);
      if (placemarks.isNotEmpty && mounted) {
        setState(() {
          _position = pos;
          _street = placemarks.first.street ?? '';
          _houseNumber = placemarks.first.subThoroughfare ?? '';
        });
      }
    } catch (_) {}
  }

  Future<void> _takePhoto() async {
    if (_cameraController == null || !_isCameraReady) return;
    try {
      final xFile = await _cameraController!.takePicture();
      setState(() {
        _mediaFile = File(xFile.path);
        _mediaType = IncidentType.photo;
        _showForm = true;
      });
    } catch (e) {
      _showError('Nepodařilo se pořídit foto');
    }
  }

  Future<void> _startVideo() async {
    if (_cameraController == null || !_isCameraReady) return;
    await _cameraController!.startVideoRecording();
    setState(() => _isRecording = true);

    // Auto-stop after 15 seconds
    Future.delayed(const Duration(seconds: 15), _stopVideo);
  }

  Future<void> _stopVideo() async {
    if (!_isRecording) return;
    try {
      final xFile = await _cameraController!.stopVideoRecording();
      setState(() {
        _mediaFile = File(xFile.path);
        _mediaType = IncidentType.video;
        _isRecording = false;
        _showForm = true;
      });
    } catch (e) {
      setState(() => _isRecording = false);
    }
  }

  Future<void> _submit() async {
    final description = _descriptionController.text.trim();
    if (description.isEmpty) {
      _showError('Napište krátký popis');
      return;
    }

    final user = context.read<AuthService>().userModel;
    if (user == null) return;

    setState(() => _isLoading = true);

    try {
      await context.read<IncidentService>().reportIncident(
        userId: user.uid,
        userName: user.name,
        street: _street,
        houseNumber: _houseNumber,
        latitude: _position?.latitude ?? 0,
        longitude: _position?.longitude ?? 0,
        description: description,
        type: _mediaFile != null ? _mediaType : IncidentType.text,
        mediaFile: _mediaFile,
      );

      // Award points
      await context.read<AuthService>().addPoints(3);

      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      _showError('Odeslání selhalo: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: AppColors.danger),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: const Text('Nahlásit podezření'),
        actions: [
          if (!_showForm)
            TextButton(
              onPressed: () => setState(() {
                _showForm = true;
                _mediaType = IncidentType.text;
              }),
              child: const Text('Jen text', style: TextStyle(color: Colors.white)),
            ),
        ],
      ),
      body: _showForm ? _buildForm() : _buildCamera(),
    );
  }

  Widget _buildCamera() {
    if (!_isCameraReady) {
      return const Center(child: CircularProgressIndicator(color: Colors.white));
    }

    return Stack(
      children: [
        // Camera preview
        Positioned.fill(child: CameraPreview(_cameraController!)),

        // Recording indicator
        if (_isRecording)
          Positioned(
            top: 20,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.danger,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.fiber_manual_record, color: Colors.white, size: 12),
                      SizedBox(width: 6),
                      Text('Nahrává se • max 15 s', style: TextStyle(color: Colors.white, fontSize: 13)),
                    ],
                  ),
                ),
              ],
            ),
          ),

        // Controls at bottom
        Positioned(
          bottom: 40,
          left: 0,
          right: 0,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // Photo button
              GestureDetector(
                onTap: _isRecording ? null : _takePhoto,
                child: Column(
                  children: [
                    Container(
                      width: 72,
                      height: 72,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.grey.shade400, width: 3),
                      ),
                      child: const Icon(Icons.camera_alt_rounded, size: 32),
                    ),
                    const SizedBox(height: 8),
                    const Text('Foto', style: TextStyle(color: Colors.white)),
                  ],
                ),
              ),

              // Video button
              GestureDetector(
                onTap: _isRecording ? _stopVideo : _startVideo,
                child: Column(
                  children: [
                    Container(
                      width: 72,
                      height: 72,
                      decoration: BoxDecoration(
                        color: _isRecording ? AppColors.danger : Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.grey.shade400, width: 3),
                      ),
                      child: Icon(
                        _isRecording ? Icons.stop_rounded : Icons.videocam_rounded,
                        size: 32,
                        color: _isRecording ? Colors.white : Colors.black,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _isRecording ? 'Zastavit' : 'Video (15 s)',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildForm() {
    return Container(
      color: AppColors.background,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Media preview
            if (_mediaFile != null)
              Container(
                height: 200,
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  image: _mediaType == IncidentType.photo
                      ? DecorationImage(
                          image: FileImage(_mediaFile!),
                          fit: BoxFit.cover,
                        )
                      : null,
                  color: Colors.black87,
                ),
                child: _mediaType == IncidentType.video
                    ? const Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.videocam_rounded, color: Colors.white, size: 48),
                            SizedBox(height: 8),
                            Text('Video nahráno', style: TextStyle(color: Colors.white)),
                          ],
                        ),
                      )
                    : null,
              ),

            // Location
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(Icons.location_on, color: AppColors.primary, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _street.isNotEmpty
                          ? '$_street $_houseNumber'
                          : 'Zjišťuji polohu...',
                      style: const TextStyle(fontWeight: FontWeight.w500),
                    ),
                  ),
                  const Icon(Icons.check_circle, color: AppColors.success, size: 18),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Description
            TextField(
              controller: _descriptionController,
              maxLength: 100,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Co se děje? (max 100 znaků)',
                hintText: 'Popis situace...',
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 8),

            // Info banner
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.primary.withOpacity(0.3)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.notifications_active_outlined, color: AppColors.primary, size: 18),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Hlášení bude okamžitě odesláno všem sousedům do 100 m od místa.',
                      style: TextStyle(fontSize: 13, color: AppColors.primary),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Submit
            ElevatedButton.icon(
              onPressed: _isLoading ? null : _submit,
              icon: _isLoading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                    )
                  : const Icon(Icons.send_rounded),
              label: const Text('Odeslat hlášení'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.danger,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    _descriptionController.dispose();
    super.dispose();
  }
}
