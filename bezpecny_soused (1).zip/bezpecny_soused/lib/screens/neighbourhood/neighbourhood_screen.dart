// lib/screens/neighbourhood/neighbourhood_screen.dart
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import '../../services/auth_service.dart';
import '../../services/incident_service.dart';
import '../../models/incident_model.dart';
import '../../theme/app_theme.dart';
import '../../widgets/incident_card.dart';

class NeighbourhoodScreen extends StatefulWidget {
  const NeighbourhoodScreen({super.key});

  @override
  State<NeighbourhoodScreen> createState() => _NeighbourhoodScreenState();
}

class _NeighbourhoodScreenState extends State<NeighbourhoodScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Moje okolí'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Mapa'),
            Tab(text: 'Seznam hlášení'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _MapView(),
          _IncidentListView(),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
}

class _MapView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: context.read<IncidentService>().getCurrentLocation(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final pos = snap.data!;

        return StreamBuilder<List<IncidentModel>>(
          stream: context.read<IncidentService>().nearbyIncidentsStream(
            pos.latitude,
            pos.longitude,
            radiusMeters: 150,
          ),
          builder: (context, incidentSnap) {
            final incidents = incidentSnap.data ?? [];

            final markers = incidents.map((i) => Marker(
              markerId: MarkerId(i.id),
              position: LatLng(i.latitude, i.longitude),
              icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
              infoWindow: InfoWindow(
                title: i.description,
                snippet: '${i.locationLabel} • ${i.timeAgo}',
              ),
            )).toSet();

            return GoogleMap(
              initialCameraPosition: CameraPosition(
                target: LatLng(pos.latitude, pos.longitude),
                zoom: 15,
              ),
              markers: markers,
              myLocationEnabled: true,
              myLocationButtonEnabled: true,
              circles: {
                Circle(
                  circleId: const CircleId('radius150'),
                  center: LatLng(pos.latitude, pos.longitude),
                  radius: 150,
                  fillColor: AppColors.primary.withOpacity(0.08),
                  strokeColor: AppColors.primary.withOpacity(0.4),
                  strokeWidth: 2,
                ),
              },
            );
          },
        );
      },
    );
  }
}

class _IncidentListView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: context.read<IncidentService>().getCurrentLocation(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final pos = snap.data!;

        return StreamBuilder<List<IncidentModel>>(
          stream: context.read<IncidentService>().nearbyIncidentsStream(
            pos.latitude,
            pos.longitude,
          ),
          builder: (context, snap) {
            final incidents = snap.data ?? [];

            if (incidents.isEmpty) {
              return const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.check_circle_outline, color: AppColors.success, size: 64),
                    SizedBox(height: 16),
                    Text('Žádné incidenty v okolí',
                        style: TextStyle(fontSize: 17, color: AppColors.textSecondary)),
                  ],
                ),
              );
            }

            return ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: incidents.length,
              itemBuilder: (context, i) => IncidentCard(incident: incidents[i]),
            );
          },
        );
      },
    );
  }
}
